package com.eis.pl;
import com.eis.bean.*;
import com.eis.service.*;


public class Main {
	
	public static void main(String[] args) {
		Employee emp = new Employee(1, "Ramu", 15000, "Peon");
		
		Service service = new Service();
		
		service.getEmployeeDetailsFromUser(emp);

		service.displayEmployeeDetails();
		
		String scheme = service.searchScheme();
		
		emp.setInsuranceScheme(scheme);
		
		service.displayEmployeeDetails();
	}
}
