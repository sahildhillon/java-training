package com.eis.service;
import com.eis.bean.*;

public interface EmployeeService {
	
	void getEmployeeDetailsFromUser(Employee employee);
	
	void displayEmployeeDetails();
	
	String searchScheme();
	
}
