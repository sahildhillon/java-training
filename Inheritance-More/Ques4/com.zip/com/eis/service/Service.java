package com.eis.service;

import com.eis.bean.Employee;

public class Service implements EmployeeService {
	private Employee employee;
	private String[] schemes = {"A1","A2","A3","B1","B2","B3"};
	@Override
	public void getEmployeeDetailsFromUser(Employee employee) {
		// TODO Auto-generated method stub
		this.employee = employee;
	}

	@Override
	public void displayEmployeeDetails() {
		// TODO Auto-generated method stub
		System.out.println("Employee Id: "+employee.getId());
		System.out.println("Employee Name: "+employee.getName());
		System.out.println("Employee Designation: "+employee.getDesignation());
		System.out.println("Employee Salary: "+employee.getSalary());
		System.out.println("Employee Scheme: "+employee.getInsuranceScheme());
	}

	@Override
	public String searchScheme() {
		// TODO Auto-generated method stub
		if (employee.getSalary() > 10000 && employee.getDesignation().equals("Peon")) {
			System.out.println("Available Schemes: "+schemes[0]);
			return schemes[0];
		}else if(employee.getSalary() > 20000 && employee.getDesignation().equals("Manager")) {
			System.out.println("Available Schemes: "+schemes[1]);
			return schemes[1];
		}else {
			System.out.println("Available Schemes: None");
			return null;
		}
	}
	
}
